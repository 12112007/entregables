package abstraccion;

import clase_base.Hamburguesa;

public abstract class DecoradorHamburguesa extends Hamburguesa {

    @Override
    public abstract String getDescripcion();
}

