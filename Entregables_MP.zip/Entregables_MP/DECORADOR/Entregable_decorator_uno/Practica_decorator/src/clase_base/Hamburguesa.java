package clase_base;

public class Hamburguesa {
    
    public String getDescripcion() {
        return "PAN + CARNE";
    }
}
