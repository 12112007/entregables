package practica_decorator;

import clase_base.Hamburguesa;
import decorador.Queso;
import decorador.Tocineta;
import decorador.Salsa;
import java.util.Scanner;

public class PracticaDecorator {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println();
        System.out.println("****************************************");
        System.out.println("BIENVENIDO A SU CREADOR DE HAMBURGUESAS");
        System.out.println("****************************************");
        System.out.println();

        Hamburguesa orden = new Hamburguesa();
        int op = 0;

        do {
            System.out.println("AGREGUE INGREDIENTOS A SU HAMBURGUESA:");
            System.out.println("1. QUESO");
            System.out.println("2. TOCINETA");
            System.out.println("3. SALSA ESPECIAL");
            System.out.println("0. TERMINAR PEDIDO");
            System.out.print("OPCIÓN: ");
            op = sc.nextInt();

            switch (op) {
                case 1:
                    orden = new Queso(orden);
                    break;
                case 2:
                    orden = new Tocineta(orden);
                    break;
                case 3:
                    orden = new Salsa(orden);
                    break;
                case 0:
                    break;
                default:
                    System.out.println("Opción inválida.");
            }

        } while (op != 0);

        System.out.println();
        System.out.println("SU HAMBURGUESA:");
        System.out.println(orden.getDescripcion());
        System.out.println();
        System.out.println("¡BUEN PROVECHO!");
    }
}
