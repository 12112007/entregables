package practica_decorator;

import clase_base.Pizza;
import decorador.QuesoExtra;
import decorador.Pepperoni;
import decorador.Champinones;
import java.util.Scanner;

public class PracticaDecorator {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println();
        System.out.println("*******************************");
        System.out.println("BIENVENIDO A PIZZERÍA JAVA 🍕");
        System.out.println("*******************************");
        System.out.println();

        Pizza pedido = new Pizza();
        int op = 0;

        do {
            System.out.println("AGREGA INGREDIENTES A TU PIZZA:");
            System.out.println("1. QUESO EXTRA");
            System.out.println("2. PEPPERONI");
            System.out.println("3. CHAMPIÑONES");
            System.out.println("0. TERMINAR PEDIDO");
            System.out.print("OPCIÓN: ");
            op = sc.nextInt();

            switch (op) {
                case 1:
                    pedido = new QuesoExtra(pedido);
                    break;
                case 2:
                    pedido = new Pepperoni(pedido);
                    break;
                case 3:
                    pedido = new Champinones(pedido);
                    break;
                case 0:
                    break;
                default:
                    System.out.println("Opción inválida.");
            }

        } while (op != 0);

        System.out.println();
        System.out.println("TU PIZZA:");
        System.out.println(pedido.getDescripcion());
        System.out.println();
        System.out.println("¡DISFRUTA TU ORDEN!");
    }
}
