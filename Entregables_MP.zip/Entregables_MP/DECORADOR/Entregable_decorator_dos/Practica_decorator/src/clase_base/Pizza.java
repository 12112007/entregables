package clase_base;

public class Pizza {
    
    public String getDescripcion() {
        return "MASA + SALSA DE TOMATE";
    }
}
