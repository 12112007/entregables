package abstraccion;

import clase_base.Pizza;

public abstract class DecoradorPizza extends Pizza {

    @Override
    public abstract String getDescripcion();
}

