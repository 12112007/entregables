package decorador;

import clase_base.Pizza;
import abstraccion.DecoradorPizza;

public class QuesoExtra extends DecoradorPizza {

    private Pizza pizza;

    public QuesoExtra(Pizza p) {
        this.pizza = p;
    }

    @Override
    public String getDescripcion() {
        return pizza.getDescripcion() + " + QUESO EXTRA";
    }
}


