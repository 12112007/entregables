package decorador;

import clase_base.Pizza;
import abstraccion.DecoradorPizza;

public class Pepperoni extends DecoradorPizza {

    private Pizza pizza;

    public Pepperoni(Pizza p) {
        this.pizza = p;
    }

    @Override
    public String getDescripcion() {
        return pizza.getDescripcion() + " + PEPPERONI";
    }
}


