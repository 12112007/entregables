package decorador;

import clase_base.Pizza;
import abstraccion.DecoradorPizza;

public class Champinones extends DecoradorPizza {

    private Pizza pizza;

    public Champinones(Pizza p) {
        this.pizza = p;
    }

    @Override
    public String getDescripcion() {
        return pizza.getDescripcion() + " + CHAMPIÑONES";
    }
}

