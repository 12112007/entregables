package abstraccion;

import clase_base.Ropa;

public abstract class DecoradorRopa extends Ropa {

    @Override
    public abstract String getDescripcion();
}

