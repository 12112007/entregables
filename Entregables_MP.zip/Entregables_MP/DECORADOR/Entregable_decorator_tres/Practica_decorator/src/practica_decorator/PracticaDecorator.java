package practica_decorator;

import clase_base.Ropa;
import decorador.NombreJugador;
import decorador.NumeroJugador;
import decorador.Estampado;
import java.util.Scanner;

public class PracticaDecorator {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("**********************************");
        System.out.println("TIENDA DE ROPA DEPORTIVA JAVA 🏃‍♂️");
        System.out.println("**********************************\n");

        Ropa prenda = new Ropa();
        int op = 0;

        do {
            System.out.println("AGREGA OPCIONES A TU CAMISETA:");
            System.out.println("1. ESTAMPADO PERSONALIZADO");
            System.out.println("2. NÚMERO DEL JUGADOR");
            System.out.println("3. NOMBRE DEL JUGADOR");
            System.out.println("0. FINALIZAR PEDIDO");
            System.out.print("OPCIÓN: ");
            op = sc.nextInt();

            switch (op) {
                case 1:
                    prenda = new Estampado(prenda);
                    break;
                case 2:
                    prenda = new NumeroJugador(prenda);
                    break;
                case 3:
                    prenda = new NombreJugador(prenda);
                    break;
                case 0:
                    break;
                default:
                    System.out.println("Opción inválida.");
            }

        } while (op != 0);

        System.out.println("\nTU CAMISETA PERSONALIZADA:");
        System.out.println(prenda.getDescripcion());
        System.out.println("\n¡GRACIAS POR TU COMPRA!");
    }
}
