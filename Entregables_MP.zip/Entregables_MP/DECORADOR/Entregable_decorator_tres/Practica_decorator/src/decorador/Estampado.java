package decorador;

import clase_base.Ropa;
import abstraccion.DecoradorRopa;

public class Estampado extends DecoradorRopa {

    private Ropa ropa;

    public Estampado(Ropa r) {
        this.ropa = r;
    }

    @Override
    public String getDescripcion() {
        return ropa.getDescripcion() + " + ESTAMPADO PERSONALIZADO";
    }
}

