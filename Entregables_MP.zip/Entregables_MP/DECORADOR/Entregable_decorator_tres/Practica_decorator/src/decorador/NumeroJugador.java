package decorador;

import clase_base.Ropa;
import abstraccion.DecoradorRopa;

public class NumeroJugador extends DecoradorRopa {

    private Ropa ropa;

    public NumeroJugador(Ropa r) {
        this.ropa = r;
    }

    @Override
    public String getDescripcion() {
        return ropa.getDescripcion() + " + NÚMERO DEL JUGADOR";
    }
}


