package decorador;

import clase_base.Ropa;
import abstraccion.DecoradorRopa;

public class NombreJugador extends DecoradorRopa {

    private Ropa ropa;

    public NombreJugador(Ropa r) {
        this.ropa = r;
    }

    @Override
    public String getDescripcion() {
        return ropa.getDescripcion() + " + NOMBRE DEL JUGADOR";
    }
}


