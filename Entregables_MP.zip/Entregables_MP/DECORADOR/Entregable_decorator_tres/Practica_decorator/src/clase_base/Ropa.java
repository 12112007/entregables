package clase_base;

public class Ropa {
    public String getDescripcion() {
        return "CAMISETA BÁSICA";
    }
}
