package practica_bridge;

import abstraccion.ControlAvanzado;
import abstraccion.ControlBasico;
import abstraccion.ControlLuz;
import implementador.ILuz;
import implementador.LuzLED;
import implementador.LuzIncandescente;

public class Practica_Bridge {
    public static void main(String[] args) {
        ILuz luzLed = new LuzLED();
        ControlLuz controlBasico = new ControlBasico(luzLed);
        controlBasico.encender();
        controlBasico.aumentarIntensidad(); // no disponible
        controlBasico.apagar();

        System.out.println();

        ILuz luzIncandescente = new LuzIncandescente();
        ControlLuz controlAvanzado = new ControlAvanzado(luzIncandescente);
        controlAvanzado.encender();
        controlAvanzado.aumentarIntensidad();
        controlAvanzado.disminuirIntensidad();
        controlAvanzado.apagar();
    }
}
