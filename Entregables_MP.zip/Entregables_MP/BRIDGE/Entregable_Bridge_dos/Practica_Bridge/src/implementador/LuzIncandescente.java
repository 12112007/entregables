package implementador;

public class LuzIncandescente implements ILuz {
    private int intensidad = 10;

    @Override
    public void encender() {
        System.out.println("Luz incandescente encendida.");
    }

    @Override
    public void apagar() {
        System.out.println("Luz incandescente apagada.");
    }

    @Override
    public void cambiarIntensidad(int cambio) {
        intensidad += cambio;
        System.out.println("Intensidad de Luz Incandescente ahora es: " + intensidad);
    }
}
