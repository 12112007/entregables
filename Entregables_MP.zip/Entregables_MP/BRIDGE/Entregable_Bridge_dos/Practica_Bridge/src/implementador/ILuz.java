package implementador;

public interface ILuz {
    void encender();
    void apagar();
    void cambiarIntensidad(int cambio);
}
