package implementador;

public class LuzLED implements ILuz {
    private int intensidad = 5;

    @Override
    public void encender() {
        System.out.println("Luz LED encendida.");
    }

    @Override
    public void apagar() {
        System.out.println("Luz LED apagada.");
    }

    @Override
    public void cambiarIntensidad(int cambio) {
        intensidad += cambio;
        System.out.println("Intensidad de Luz LED ahora es: " + intensidad);
    }
}


