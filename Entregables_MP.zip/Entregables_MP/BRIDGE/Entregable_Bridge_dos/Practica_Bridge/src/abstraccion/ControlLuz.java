package abstraccion;

import implementador.ILuz;

public abstract class ControlLuz {
    protected ILuz luz;

    public ControlLuz(ILuz luz) {
        this.luz = luz;
    }

    public abstract void encender();
    public abstract void apagar();
    public abstract void aumentarIntensidad();
    public abstract void disminuirIntensidad();
}
