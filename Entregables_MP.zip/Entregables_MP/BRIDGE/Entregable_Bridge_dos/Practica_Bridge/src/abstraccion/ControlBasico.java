package abstraccion;

import implementador.ILuz;

public class ControlBasico extends ControlLuz {

    public ControlBasico(ILuz luz) {
        super(luz);
    }

    @Override
    public void encender() {
        luz.encender();
    }

    @Override
    public void apagar() {
        luz.apagar();
    }

    @Override
    public void aumentarIntensidad() {
        System.out.println("Control básico: No puede aumentar la intensidad.");
    }

    @Override
    public void disminuirIntensidad() {
        System.out.println("Control básico: No puede disminuir la intensidad.");
    }
}
