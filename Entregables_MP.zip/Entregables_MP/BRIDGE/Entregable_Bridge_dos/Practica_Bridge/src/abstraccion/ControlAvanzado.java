package abstraccion;

import implementador.ILuz;

public class ControlAvanzado extends ControlLuz {

    public ControlAvanzado(ILuz luz) {
        super(luz);
    }

    @Override
    public void encender() {
        luz.encender();
    }

    @Override
    public void apagar() {
        luz.apagar();
    }

    @Override
    public void aumentarIntensidad() {
        luz.cambiarIntensidad(1);
    }

    @Override
    public void disminuirIntensidad() {
        luz.cambiarIntensidad(-1);
    }
}
