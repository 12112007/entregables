package abstraccion;

import implementador.IImpresora;

public class ControlBasico extends ControlImpresora {

    public ControlBasico(IImpresora impresora) {
        super(impresora);
    }

    @Override
    public void imprimirDocumento() {
        impresora.imprimir();
    }

    @Override
    public void cancelarImpresion() {
        impresora.cancelar();
    }

    @Override
    public void configurarCalidad(String calidad) {
        System.out.println("Control básico no permite configurar calidad.");
    }
}
