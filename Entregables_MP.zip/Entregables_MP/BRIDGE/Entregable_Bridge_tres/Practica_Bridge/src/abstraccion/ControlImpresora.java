package abstraccion;

import implementador.IImpresora;

public abstract class ControlImpresora {
    protected IImpresora impresora;

    public ControlImpresora(IImpresora impresora) {
        this.impresora = impresora;
    }

    public abstract void imprimirDocumento();
    public abstract void cancelarImpresion();
    public abstract void configurarCalidad(String calidad);
}
