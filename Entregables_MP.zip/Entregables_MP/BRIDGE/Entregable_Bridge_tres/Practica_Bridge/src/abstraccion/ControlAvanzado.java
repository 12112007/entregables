package abstraccion;

import implementador.IImpresora;

public class ControlAvanzado extends ControlImpresora {

    public ControlAvanzado(IImpresora impresora) {
        super(impresora);
    }

    @Override
    public void imprimirDocumento() {
        impresora.imprimir();
    }

    @Override
    public void cancelarImpresion() {
        impresora.cancelar();
    }

    @Override
    public void configurarCalidad(String calidad) {
        impresora.configurarCalidad(calidad);
    }
}

