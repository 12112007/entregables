package implementador;

public class ImpresoraTinta implements IImpresora {

    @Override
    public void imprimir() {
        System.out.println("Imprimiendo con impresora de tinta...");
    }

    @Override
    public void cancelar() {
        System.out.println("Impresión de tinta cancelada.");
    }

    @Override
    public void configurarCalidad(String calidad) {
        System.out.println("Calidad de impresión de tinta configurada a: " + calidad);
    }
}
