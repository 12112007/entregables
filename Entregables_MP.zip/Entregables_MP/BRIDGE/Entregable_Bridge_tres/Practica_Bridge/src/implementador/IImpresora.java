package implementador;

public interface IImpresora {
    void imprimir();
    void cancelar();
    void configurarCalidad(String calidad);
}
