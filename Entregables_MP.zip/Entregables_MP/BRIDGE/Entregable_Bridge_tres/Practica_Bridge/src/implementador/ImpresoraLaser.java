package implementador;

public class ImpresoraLaser implements IImpresora {

    @Override
    public void imprimir() {
        System.out.println("Imprimiendo con impresora láser...");
    }

    @Override
    public void cancelar() {
        System.out.println("Impresión láser cancelada.");
    }

    @Override
    public void configurarCalidad(String calidad) {
        System.out.println("Calidad de impresión láser configurada a: " + calidad);
    }
}
