package practica_bridge;

import abstraccion.*;
import implementador.*;

public class Practica_Bridge {

    public static void main(String[] args) {
        IImpresora laser = new ImpresoraLaser();
        ControlImpresora controlBasico = new ControlBasico(laser);
        controlBasico.imprimirDocumento();
        controlBasico.configurarCalidad("Alta"); // No puede

        System.out.println();

        IImpresora tinta = new ImpresoraTinta();
        ControlImpresora controlAvanzado = new ControlAvanzado(tinta);
        controlAvanzado.imprimirDocumento();
        controlAvanzado.configurarCalidad("Media");
        controlAvanzado.cancelarImpresion();
    }
}
