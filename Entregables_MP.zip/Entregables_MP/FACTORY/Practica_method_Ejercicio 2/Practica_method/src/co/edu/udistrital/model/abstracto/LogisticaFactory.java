package co.edu.udistrital.model.abstracto;

public interface LogisticaFactory {
    
    Logistica crearEntrega(String direccion,String peso,String tipo);
    
}
