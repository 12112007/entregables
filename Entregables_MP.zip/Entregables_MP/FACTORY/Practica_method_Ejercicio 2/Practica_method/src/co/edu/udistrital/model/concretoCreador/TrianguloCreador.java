package co.edu.udistrital.model.concretoCreador;

import co.edu.udistrital.model.*;
import co.edu.udistrital.model.abstracto.Logistica;
import co.edu.udistrital.model.abstracto.LogisticaFactory;

public class TrianguloCreador implements LogisticaFactory {

	@Override
	public Logistica crearTriangulo(int ladoA, int ladoB, int ladoc) {
		if ((ladoA == ladoB) && (ladoA == ladoc)) {
			return new entregaPorTierra(ladoA, ladoB, ladoc);
		} else if ((ladoA != ladoB) && (ladoA != ladoc) && (ladoB != ladoc)) {
			return new entregaPorMar(ladoA, ladoB, ladoc);
		} else {
			return new Isosceles(ladoA, ladoB, ladoc);
		}
	}

}
