package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Logistica;

public class entregaPorMar extends Logistica {

	public entregaPorMar(String direccion, String peso, String tipo) {
		super(direccion, peso, tipo);
	}

	@Override
	public String describir() {
		return "....... ENTREGA POR MAR EN UN CONTENEDOR......";
	}

	@Override
	public String tipoDeEntrega() {
		
		return null;
	}
}
