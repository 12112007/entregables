package co.edu.udistrital.model.abstracto;

public abstract class Logistica {

	protected String direccion;
	protected String peso;
	protected String tipo;

	public Logistica(String direccion,String peso,String tipo) {
		this.direccion = direccion;
		this.peso = peso;
		this.tipo = tipo;
	}

	public abstract String describir();

	//public abstract String calcularSuperficie();  BORRARRR

	public abstract String tipoDeEntrega() ;
}
