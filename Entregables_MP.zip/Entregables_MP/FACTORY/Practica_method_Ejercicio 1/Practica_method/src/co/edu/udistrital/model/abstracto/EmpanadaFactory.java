package co.edu.udistrital.model.abstracto;

public interface EmpanadaFactory {
    
    Empanada crearEmpanada(String relleno, String precio, int cantidad);
   
}
