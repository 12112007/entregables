package co.edu.udistrital.controller;

import co.edu.udistrital.model.abstracto.*;
import co.edu.udistrital.model.concretoCreador.*;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

	private VistaConsola vista;
	
    public Controller() {
    	vista = new VistaConsola();
	}
    
    public void run() {
    	String relleno = "" ;
    	String precio = "";
    	int cantidad= 0;
    	
        vista.mostrarInformacion("DATOS DE LA EMPANADA ");
        
        relleno = vista.leerDatoTexto("\t" + "Digite tipo de empanada (Carne, Pollo, Queso): ");
        cantidad = vista.leerDatoEntero("\t" + "Digite la cantidad de empanadas: ");
       
        
        EmpanadaFactory fabrica=new EmpandaCreador();
        
        Empanada empanada = fabrica.crearEmpanada(relleno,precio,cantidad);
        
        vista.mostrarInformacion("EL RELLENO DE LA EMPANADA ES DE....." + empanada.mostrarInfo());
        vista.mostrarInformacion("COSTO TOTAL....." + empanada.calcularPrecioTotal());

    }
    
}
