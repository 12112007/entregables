package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Empanada;

public class Carne extends Empanada {

	public Carne(int cantidad) {
		super("Carne","Precio", cantidad);
	}

	@Override
	public String mostrarInfo() {
		return "Carne - Precio Unidad: $3000 - Cantidad: " + cantidad;
		
	}

	@Override
	public String calcularPrecioTotal() {
		int x;
		String res;
		x = cantidad*3000;
		res = Integer.toString(x);
		return res;
	}
	
	
}
