package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Empanada;
public class Queso extends Empanada{
	
	public  Queso( int cantidad) {
		super("Queso","Precio", cantidad);
	}

	@Override
    public String mostrarInfo() {
		return "Carne - Precio Unidad: $3800 - Cantidad: " + cantidad;
    }
	
	@Override
	public String calcularPrecioTotal() {
		int x;
		String res;
		x = cantidad*3800;
		res = Integer.toString(x);
		return res;
	}
}
