package co.edu.udistrital.model.abstracto;

public abstract class Empanada {

	protected String relleno;
	protected String precio;
	protected int cantidad;


	public Empanada(String relleno,  String precio, int cantidad) {
		this.relleno = relleno;
		this.precio = precio;
		this.cantidad = cantidad;
	
	}

	public abstract String mostrarInfo();
	public abstract String calcularPrecioTotal();

}
