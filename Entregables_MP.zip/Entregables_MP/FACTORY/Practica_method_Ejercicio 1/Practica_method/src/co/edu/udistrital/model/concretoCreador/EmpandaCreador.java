package co.edu.udistrital.model.concretoCreador;

import co.edu.udistrital.model.*;
import co.edu.udistrital.model.abstracto.Empanada;
import co.edu.udistrital.model.abstracto.EmpanadaFactory;

public class EmpandaCreador implements EmpanadaFactory {


	@Override
	public Empanada crearEmpanada(String relleno, String precio, int cantidad) {
		switch(relleno.trim().toLowerCase()) {
		case "pollo":
            return new Pollo(cantidad);
        case "carne":
            return new Carne(cantidad);
        case "queso":
            return new Queso(cantidad);
        default:
            throw new IllegalArgumentException("Tipo de empanada no válida: " + relleno);
		}
	}

}
