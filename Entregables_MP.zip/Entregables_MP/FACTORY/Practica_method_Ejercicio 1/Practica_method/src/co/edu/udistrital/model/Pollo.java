package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Empanada;

public class Pollo extends Empanada {

	public Pollo(int cantidad) {
		super("Pollo","Precio", cantidad);
	}



	@Override
    public String mostrarInfo() {
		return "Pollo - Precio Unidad: $2800 - Cantidad: " + cantidad;
    }
	
	@Override
	public String calcularPrecioTotal() {
		int x;
		String res;
		x = cantidad*2800;
		res = Integer.toString(x);
		return res;
	}
}
