package co.edu.udistrital.controller;

import co.edu.udistrital.model.AutorUnico;
import co.edu.udistrital.view.VistaConsola;


public class Controller {

	private VistaConsola vista;
	
    public Controller() {
    	vista = new VistaConsola();
	}
    
    public void run() {
    	
    	AutorUnico  obj= AutorUnico.getinstancia();//creacio  de la instancia unica
        AutorUnico otra = AutorUnico.getinstancia();
        obj.setPruebaInstancia("MEGAN MAXWELL");
        vista.mostrarInformacion(otra.getPruebaInstancia());
        vista.mostrarInformacion(obj.getPruebaInstancia());
        obj.setPruebaInstancia("MARIO MENDOSA");
        vista.mostrarInformacion(otra.getPruebaInstancia());
        vista.mostrarInformacion(obj.getPruebaInstancia());
       
      
            
    }
        
}
