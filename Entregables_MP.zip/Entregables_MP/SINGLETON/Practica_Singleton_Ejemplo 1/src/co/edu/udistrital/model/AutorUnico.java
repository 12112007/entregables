package co.edu.udistrital.model;


public class AutorUnico {

	private static AutorUnico instancia = null;
	private String PruebaInstancia = null;

	private AutorUnico() {

	}

	public static AutorUnico getinstancia() {

		if (instancia == null) {
			instancia = new AutorUnico();
		}
		return instancia;
	}

	public void direccion(String dire) {
		System.out.println(dire);
	}

	public void setPruebaInstancia(String salida) {
		PruebaInstancia = salida;
	}

	public String getPruebaInstancia() {
		return PruebaInstancia;
	}
}
