package co.edu.udistrital.model;


public class LenteUnico {

	private static LenteUnico instancia = null;
	private String PruebaInstancia = null;

	private LenteUnico() {

	}

	public static LenteUnico getinstancia() {

		if (instancia == null) {
			instancia = new LenteUnico();
		}
		return instancia;
	}

	public void direccion(String dire) {
		System.out.println(dire);
	}

	public void setPruebaInstancia(String salida) {
		PruebaInstancia = salida;
	}

	public String getPruebaInstancia() {
		return PruebaInstancia;
	}
}
