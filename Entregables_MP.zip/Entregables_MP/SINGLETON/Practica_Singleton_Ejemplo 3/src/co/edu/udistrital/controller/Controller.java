package co.edu.udistrital.controller;

import co.edu.udistrital.model.LenteUnico;
import co.edu.udistrital.view.VistaConsola;


public class Controller {

	private VistaConsola vista;
	
    public Controller() {
    	vista = new VistaConsola();
	}
    
    public void run() {
    	
    	LenteUnico  obj= LenteUnico.getinstancia();//creacio  de la instancia unica
        LenteUnico otra = LenteUnico.getinstancia();
        obj.setPruebaInstancia("LENTES DE SOL");
        vista.mostrarInformacion(otra.getPruebaInstancia());
        vista.mostrarInformacion(obj.getPruebaInstancia());
        obj.setPruebaInstancia("LENTES DE LECTURA");
        vista.mostrarInformacion(otra.getPruebaInstancia());
        vista.mostrarInformacion(obj.getPruebaInstancia());
        
            
    }
        
}
