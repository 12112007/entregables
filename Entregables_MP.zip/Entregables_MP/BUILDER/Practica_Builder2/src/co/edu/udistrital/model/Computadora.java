package co.edu.udistrital.model;

public class Computadora {
	
	private String procesador;
    private String ram;
    private String almacenamiento;
    private String tarjetaGrafica;
    private String sistemaOperativo;
    
	public String getProcesador() {
		return procesador;
	}
	public void setProcesador(String procesador) {
		this.procesador = procesador;
	}
	public String getRam() {
		return ram;
	}
	public void setRam(String ram) {
		this.ram = ram;
	}
	public String getAlmacenamiento() {
		return almacenamiento;
	}
	public void setAlmacenamiento(String almacenamiento) {
		this.almacenamiento = almacenamiento;
	}
	public String getTarjetaGrafica() {
		return tarjetaGrafica;
	}
	public void setTarjetaGrafica(String tarjetaGrafica) {
		this.tarjetaGrafica = tarjetaGrafica;
	}
	public String getSistemaOperativo() {
		return sistemaOperativo;
	}
	public void setSistemaOperativo(String sistemaOperativo) {
		this.sistemaOperativo = sistemaOperativo;
	}
	@Override
	public String toString() {
		return "Computadora\n"
				+ "Procesador=" + procesador 
				+ "\nRam=" + ram 
				+ "\nAlmacenamiento=" + almacenamiento 
				+ "\nTarjetaGrafica=" + tarjetaGrafica 
				+ "\nSistemaOperativo=" + sistemaOperativo ;
	}
    
	
    
	
    
	

}
