package co.edu.udistrital.model.concreto;
import co.edu.udistrital.model.Computadora;
import co.edu.udistrital.model.builder.ComputadoraBuilder;

public class ComputadoraGamer implements ComputadoraBuilder {
	
    private Computadora computadora = new Computadora();

	@Override
	public void construirProcesador() {
		computadora.setProcesador("Intel Core i9");
	}

	@Override
	public void construirRAM() {
		computadora.setRam("32 GB");
	}

	@Override
	public void construirAlmacenamiento() {
        computadora.setAlmacenamiento("1TB SSD");
    }

	@Override
    public void construirTarjetaGrafica() {
        computadora.setTarjetaGrafica("NVIDIA RTX 4090");
    }

	@Override
    public void construirSistemaOperativo() {
        computadora.setSistemaOperativo("Windows 11 Pro");
    }

	@Override
    public Computadora getComputadora() {
        return computadora;
    }

}