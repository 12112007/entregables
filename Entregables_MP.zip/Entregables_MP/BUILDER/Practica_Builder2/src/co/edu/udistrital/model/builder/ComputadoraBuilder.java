package co.edu.udistrital.model.builder;
import co.edu.udistrital.model.Computadora;

public interface ComputadoraBuilder {
	
	void construirProcesador();
    void construirRAM();
    void construirAlmacenamiento();
    void construirTarjetaGrafica();
    void construirSistemaOperativo();
    Computadora getComputadora();

}
