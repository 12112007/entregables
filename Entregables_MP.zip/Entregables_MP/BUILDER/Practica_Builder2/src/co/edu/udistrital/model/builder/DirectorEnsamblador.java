package co.edu.udistrital.model.builder;

import co.edu.udistrital.model.Computadora;

public class DirectorEnsamblador {
	
	private ComputadoraBuilder builder;

	 public DirectorEnsamblador(ComputadoraBuilder builder) {
	        this.builder = builder;
	    }

	 public void construirComputadora() {
	        builder.construirProcesador();
	        builder.construirRAM();
	        builder.construirAlmacenamiento();
	        builder.construirTarjetaGrafica();
	        builder.construirSistemaOperativo();
			
	    }

	    public Computadora obtenerComputadora() {
	        return builder.getComputadora();
	    }
}
