package co.edu.udistrital.controller;

import co.edu.udistrital.model.Computadora;
import co.edu.udistrital.model.builder.DirectorEnsamblador;
import co.edu.udistrital.model.builder.ComputadoraBuilder;
import co.edu.udistrital.model.concreto.ComputadoraGamer;
import co.edu.udistrital.model.concreto.ComputadoraOficina;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

	private VistaConsola vista;
	
    public Controller() {
    	vista = new VistaConsola();
	}
    
    public void run() { 
    	int op = 0;
    do {
        op = menu();
        switch (op) {
            case 1:
                construirComputadora(new ComputadoraOficina());
                break;
            case 2:
            	construirComputadora(new ComputadoraGamer());
                break;
            case 3:
                vista.mostrarInformacion("Cerrando Programa");
                System.exit(0);
                break;
            default:
                vista.mostrarInformacion(".....Opcion invalida....");
                }
        vista.mostrarInformacion("");
        } 
    while (op != 3);
    }
    
    public void construirComputadora(ComputadoraBuilder builder) {
    DirectorEnsamblador director = new DirectorEnsamblador(builder);
    director.construirComputadora();
    Computadora computadora = director.obtenerComputadora();
    vista.mostrarInformacion(computadora.toString());
    
    }
    
    public int menu() {
    	String menu2 =
            "MENU DE OPCIONES\n"
                    + "1. Construir Computadora De Oficina\n"
                    + "2. Construir Computadora Gamer\n"
                    + "3. Salir\n\n"
                    + "Seleccione opcion...";
    return vista.leerDatoEntero(menu2);
    }
    
}