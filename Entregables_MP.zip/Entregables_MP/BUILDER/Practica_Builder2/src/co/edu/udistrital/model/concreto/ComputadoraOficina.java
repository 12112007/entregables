package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.Computadora;
import co.edu.udistrital.model.builder.ComputadoraBuilder;

public class ComputadoraOficina implements ComputadoraBuilder{
	
    private Computadora computadora = new Computadora();

	@Override
	public void construirProcesador() {
		computadora.setProcesador("Intel Core i5");
	}

	@Override
	public void construirRAM() {
		computadora.setRam("8 GB");
	}

	@Override
	public void construirAlmacenamiento() {
		computadora.setAlmacenamiento("512GB SSD");
	}

	@Override
	public void construirTarjetaGrafica() {
		computadora.setTarjetaGrafica("Integrada Intel UHD");
	}

	@Override
	public void construirSistemaOperativo() {
		computadora.setSistemaOperativo("Windows 10 Home");
	}

	@Override
	public Computadora getComputadora() {
		return computadora;
	}

    

}
