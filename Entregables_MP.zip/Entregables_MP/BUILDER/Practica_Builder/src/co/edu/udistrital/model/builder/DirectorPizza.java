package co.edu.udistrital.model.builder;

import co.edu.udistrital.model.Pizza;

public class DirectorPizza {
	
	private PizzaBuilder builder;

	 public DirectorPizza(PizzaBuilder builder) {
	        this.builder = builder;
	    }

	    public void construirPizza() {
	        builder.buildMasa();
	        builder.buildSalsa();
	        builder.buildIngredientes();
	    }

	    public Pizza getPizza() {
	        return builder.getPizza();
	    }
}
