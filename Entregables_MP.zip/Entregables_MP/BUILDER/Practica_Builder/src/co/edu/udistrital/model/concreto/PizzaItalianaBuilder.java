package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.Pizza;
import co.edu.udistrital.model.builder.PizzaBuilder;

public class PizzaItalianaBuilder implements PizzaBuilder{
	
    private Pizza pizza = new Pizza();

    
	@Override
	public void buildMasa() {
		
		pizza.setMasa("Delgada");
		
	}

	@Override
	public void buildSalsa() {
		
		pizza.setSalsa("Tomate natural");
		
	}

	@Override
	public void buildIngredientes() {
		
        pizza.setIngredientes("Mozzarella, pepperoni, aceitunas");

	}

	@Override
	public Pizza getPizza() {
		
		return pizza;
		
	}

}
