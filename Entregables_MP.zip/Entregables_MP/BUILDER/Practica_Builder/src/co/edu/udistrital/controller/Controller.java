package co.edu.udistrital.controller;

import co.edu.udistrital.model.Pizza;
import co.edu.udistrital.model.builder.DirectorPizza;
import co.edu.udistrital.model.builder.PizzaBuilder;
import co.edu.udistrital.model.concreto.PizzaHawaianaBuilder;
import co.edu.udistrital.model.concreto.PizzaItalianaBuilder;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

	private VistaConsola vista;
	
    public Controller() {
    	vista = new VistaConsola();
	}
    
    public void run() { 
    	int op = 0;
    do {
        op = menu();
        switch (op) {
            case 1:
                construirPizza(new PizzaItalianaBuilder());
                break;
            case 2:
                construirPizza(new PizzaHawaianaBuilder());
                break;
            case 3:
                vista.mostrarInformacion("Cerrando Programa");
                System.exit(0);
                break;
            default:
                vista.mostrarInformacion(".....Opcion invalida....");
                }
        vista.mostrarInformacion("");
        } 
    while (op != 3);
    }
    
    public void construirPizza(PizzaBuilder builder) {
    DirectorPizza director = new DirectorPizza(builder);
    director.construirPizza();
    Pizza pizza = director.getPizza();
    vista.mostrarInformacion(pizza.toString());
    
    }
    
    public int menu() {
    	String menu2 =
            "MENU DE OPCIONES\n"
                    + "1. Construir Pizza Italiana\n"
                    + "2. Construir Pizza Hawaiana\n"
                    + "3. Salir\n\n"
                    + "Seleccione opcion...";
    return vista.leerDatoEntero(menu2);
    }
    
}