package co.edu.udistrital.model.concreto;
import co.edu.udistrital.model.Pizza;
import co.edu.udistrital.model.builder.PizzaBuilder;

public class PizzaHawaianaBuilder implements PizzaBuilder {
	
    private Pizza pizza = new Pizza();

    
	@Override
	public void buildMasa() {
		
		 pizza.setMasa("Gruesa");
		
	}

	@Override
	public void buildSalsa() {
		
        pizza.setSalsa("Barbacoa");
		
	}

	@Override
	public void buildIngredientes() {
		
		pizza.setIngredientes("Jamón, piña, queso");
		
	}

	@Override
	public Pizza getPizza() {

		return pizza;

	}

}
