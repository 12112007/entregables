package co.edu.udistrital.model.builder;
import co.edu.udistrital.model.Pizza;

public interface PizzaBuilder {
	void buildMasa();
    void buildSalsa();
    void buildIngredientes();
    Pizza getPizza();

}
