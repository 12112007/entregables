package co.edu.udistrital.model;

public class Vehiculo {
	
	private String motor;
    private String puertas;
    private String color;
    private String tipo;
    
	public String getMotor() {
		return motor;
	}
	public void setMotor(String motor) {
		this.motor = motor;
	}
	public String getPuertas() {
		return puertas;
	}
	public void setPuertas(String puertas) {
		this.puertas = puertas;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	@Override
	public String toString() {
		return "Vehiculo\n"
				+ "Motor=" + motor 
				+ "\nPuertas=" + puertas 
				+ "\nColor=" + color 
				+ "\nTipo=" + tipo ;
	}
    
    
	
    
	

}
