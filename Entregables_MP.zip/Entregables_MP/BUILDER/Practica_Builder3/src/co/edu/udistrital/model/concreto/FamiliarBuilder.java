package co.edu.udistrital.model.concreto;
import co.edu.udistrital.model.Vehiculo;
import co.edu.udistrital.model.builder.VehiculoBuilder;

public class FamiliarBuilder implements VehiculoBuilder {
	
    private Vehiculo vehiculo = new Vehiculo();

	@Override
	public void construirMotor() {
        vehiculo.setMotor("Motor 1.6L económico");
    }

	@Override
    public void construirPuertas() {
        vehiculo.setPuertas("5 puertas");
    }

	@Override
    public void construirColor() {
        vehiculo.setColor("Gris metálico");
    }
	
	@Override
    public void definirTipo() {
        vehiculo.setTipo("Familiar");
    }

	@Override
    public Vehiculo getVehiculo() {
        return vehiculo;
    }
	
}