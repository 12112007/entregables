package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.Vehiculo;
import co.edu.udistrital.model.builder.VehiculoBuilder;

public class DeportivoBuilder implements VehiculoBuilder{
	
    private Vehiculo vehiculo = new Vehiculo();

	@Override
	public void construirMotor() {
        vehiculo.setMotor("Motor V8 turbo");
    }

	@Override
    public void construirPuertas() {
        vehiculo.setPuertas("2 puertas");
    }

	@Override
    public void construirColor() {
        vehiculo.setColor("Rojo brillante");
    }

	@Override
    public void definirTipo() {
        vehiculo.setTipo("Deportivo");
    }

	@Override
    public Vehiculo getVehiculo() {
        return vehiculo;
    }

	
    

}
