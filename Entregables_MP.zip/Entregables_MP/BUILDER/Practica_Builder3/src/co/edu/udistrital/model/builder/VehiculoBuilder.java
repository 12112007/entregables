package co.edu.udistrital.model.builder;
import co.edu.udistrital.model.Vehiculo;

public interface VehiculoBuilder {
	
	    void construirMotor();
	    void construirPuertas();
	    void construirColor();
	    void definirTipo();
	    Vehiculo getVehiculo();

}
