package co.edu.udistrital.model.builder;

import co.edu.udistrital.model.Vehiculo;

public class DirectorVehiculo {
	
	private VehiculoBuilder builder;

	 public DirectorVehiculo(VehiculoBuilder builder) {
	        this.builder = builder;
	    }

	 
	 public void construirVehiculo() {
	        builder.definirTipo();
	        builder.construirMotor();
	        builder.construirPuertas();
	        builder.construirColor();
	    }

	    public Vehiculo obtenerVehiculo() {
	        return builder.getVehiculo();
	    }


}
