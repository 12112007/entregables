package co.edu.udistrital.controller;

import co.edu.udistrital.model.Vehiculo;
import co.edu.udistrital.model.builder.DirectorVehiculo;
import co.edu.udistrital.model.builder.VehiculoBuilder;
import co.edu.udistrital.model.concreto.FamiliarBuilder;
import co.edu.udistrital.model.concreto.DeportivoBuilder;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

	private VistaConsola vista;
	
    public Controller() {
    	vista = new VistaConsola();
	}
    
    public void run() { 
    	int op = 0;
    do {
        op = menu();
        switch (op) {
            case 1:
            	construirVehiculo(new DeportivoBuilder());
                break;
            case 2:
            	construirVehiculo(new FamiliarBuilder());
                break;
            case 3:
                vista.mostrarInformacion("Cerrando Programa");
                System.exit(0);
                break;
            default:
                vista.mostrarInformacion(".....Opcion invalida....");
                }
        vista.mostrarInformacion("");
        } 
    while (op != 3);
    }
    
    public void construirVehiculo(VehiculoBuilder builder) {
    DirectorVehiculo director = new DirectorVehiculo(builder);
    director.construirVehiculo();
    Vehiculo vehiculo = director.obtenerVehiculo();
    vista.mostrarInformacion(vehiculo.toString());
    
    }
    
    public int menu() {
    	String menu2 =
            "MENU DE OPCIONES\n"
                    + "1. Construir Carro Deportivo\n"
                    + "2. Construir  Carro Familiar\n"
                    + "3. Salir\n\n"
                    + "Seleccione opcion...";
    return vista.leerDatoEntero(menu2);
    }
    
}