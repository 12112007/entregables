package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Vehiculo;

public class Carro extends Vehiculo {

	public Carro(String marca, int velocidadMaxima) {
		super( marca, velocidadMaxima);
	}


	@Override
	public String  mostrarInfo() {
        return "🏍️ Moto - Marca: " + marca + ", Vel. Máxima: " + velocidadMaxima + " km/h";		
	}
}
