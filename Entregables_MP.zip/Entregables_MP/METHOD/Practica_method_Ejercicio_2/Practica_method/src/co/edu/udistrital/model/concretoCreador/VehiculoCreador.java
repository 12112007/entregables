package co.edu.udistrital.model.concretoCreador;

import co.edu.udistrital.model.*;
import co.edu.udistrital.model.abstracto.Vehiculo;
import co.edu.udistrital.model.abstracto.VehiculoFactory;

public class VehiculoCreador implements VehiculoFactory {
	
    @Override
    public Vehiculo crearVehiculo(String tipo, String marca, int velocidadMaxima) {
        switch (tipo.trim().toLowerCase()) {
            case "carro":
                return new Carro(marca, velocidadMaxima);
            case "moto":
                return new Moto(marca, velocidadMaxima);
            case "camion":
                return new Camion(marca, velocidadMaxima);
            default:
                throw new IllegalArgumentException("Tipo de vehículo no válido: " + tipo);
        }
    }



}
