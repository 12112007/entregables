package co.edu.udistrital.model.abstracto;

public interface VehiculoFactory {
    
    Vehiculo crearVehiculo(String tipo, String marca, int velocidadMaxima);
    
}
