package co.edu.udistrital.model.abstracto;

public abstract class Vehiculo {

	protected String marca;
	protected int velocidadMaxima;
	
	public Vehiculo(String marca, int velocidadMaxima) {
		this.marca = marca;
		this.velocidadMaxima=velocidadMaxima;
		
	}
	
	
	public abstract String mostrarInfo();

	

}
