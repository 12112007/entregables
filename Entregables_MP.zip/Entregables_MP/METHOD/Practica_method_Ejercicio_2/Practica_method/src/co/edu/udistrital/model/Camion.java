package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Vehiculo;

public class Camion extends Vehiculo {
    public Camion(String marca, int velocidadMaxima) {
        super(marca, velocidadMaxima);
    }

    @Override
    public String mostrarInfo() {
        return "Camión - Marca: " + marca + ", Vel. Máxima: " + velocidadMaxima + " km/h";
    }
}
