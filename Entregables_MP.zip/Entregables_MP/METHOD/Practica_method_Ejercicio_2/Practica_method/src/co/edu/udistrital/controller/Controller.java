package co.edu.udistrital.controller;

import co.edu.udistrital.model.abstracto.*;
import co.edu.udistrital.model.concretoCreador.*;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        String tipo = "";
        String marca = "";
        int velocidadMaxima = 0;

        vista.mostrarInformacion("DATOS DEL VEHICULO");

        tipo = vista.leerDatoTexto("\t" + "Digite tipo de vehiculo (Carro, Moto, Camion): ");
        marca = vista.leerDatoTexto("\t" + "Digite marca: ");
        velocidadMaxima = vista.leerDatoEntero("\t" + "Digite velocidad maxima (km/h): ");

        VehiculoFactory fabrica = new VehiculoCreador();
        Vehiculo vehiculo = fabrica.crearVehiculo(tipo, marca, velocidadMaxima);

        vista.mostrarInformacion("INFORMACIÓN DEL VEHICULO");
        vista.mostrarInformacion(vehiculo.mostrarInfo());
    }

}
