package co.edu.udistrital.model.abstracto;

public abstract class Pijama {

	protected String tela;
	protected int cantidadPiezas;
	protected String diseño;
	

	public Pijama(String tela, int cantidadPiezas, String diseño) {
		this.tela = tela;
		this.cantidadPiezas = cantidadPiezas;
		this.diseño = diseño;
	}

	public abstract String describir();



}
