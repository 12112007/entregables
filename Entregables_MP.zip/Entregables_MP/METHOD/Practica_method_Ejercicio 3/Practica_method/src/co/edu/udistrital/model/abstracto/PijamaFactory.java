package co.edu.udistrital.model.abstracto;

public interface PijamaFactory {
    
    Pijama crearPijama(String tela, int cantidadPiezas, String diseño);

	
    
}
