package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Pijama;

public class Poliester extends Pijama {

	public Poliester(int cantidadPiezas, String diseño) {
		super("Poliester", cantidadPiezas, diseño);
	}


	@Override
	public String describir() {
		return "Poliester - Cantidad de piezas: " + cantidadPiezas + " - Diseño: " + diseño;
	}
}
