package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Pijama;

public class Ovejera extends Pijama {

	public Ovejera(int cantidadPiezas, String diseño) {
		super("Ovejera", cantidadPiezas, diseño);
	}


	@Override
	public String describir() {
		return "Ovejera - Cantidad de piezas: " + cantidadPiezas + " - Diseño: " + diseño;
	}


	
}
