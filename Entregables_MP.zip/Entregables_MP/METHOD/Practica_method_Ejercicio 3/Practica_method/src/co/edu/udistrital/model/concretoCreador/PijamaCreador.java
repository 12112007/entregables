package co.edu.udistrital.model.concretoCreador;

import co.edu.udistrital.model.*;
import co.edu.udistrital.model.abstracto.Pijama;
import co.edu.udistrital.model.abstracto.PijamaFactory;

public class PijamaCreador implements PijamaFactory {

	@Override
	public Pijama crearPijama(String tela, int cantidadPiezas, String diseño) {
		switch(tela.trim().toLowerCase()) {
		case "ovejera":
			return new Ovejera(cantidadPiezas, diseño);
		case "seda":
			return new Seda(cantidadPiezas, diseño);
		case "poliester":
			return new Poliester(cantidadPiezas, diseño);
		 default:
             throw new IllegalArgumentException("Tipo de pijama no valida: " + tela);
		}
		
		
	}

}
