package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Pijama;

public class Seda extends Pijama {
	
	public Seda(int cantidadPiezas, String diseño) {
		super("Seda", cantidadPiezas, diseño);
	}


	@Override
	public String describir() {
		return "Seda - Cantidad de piezas: " + cantidadPiezas + " - Diseño: " + diseño;
	}


}
