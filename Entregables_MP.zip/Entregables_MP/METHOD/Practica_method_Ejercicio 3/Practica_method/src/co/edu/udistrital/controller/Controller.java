package co.edu.udistrital.controller;

import co.edu.udistrital.model.abstracto.*;
import co.edu.udistrital.model.concretoCreador.*;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

	private VistaConsola vista;
	
    public Controller() {
    	vista = new VistaConsola();
	}
    
    public void run() {
    	String tela = " ";
    	int cantidadPiezas = 0;
    	String diseño = " ";
    	
        vista.mostrarInformacion("DATOS DE LA PIJAMA");
        
        tela = vista.leerDatoTexto("\t" + "Digite tipo de tela (Ovejera, Seda, Poliester): ");
        cantidadPiezas = vista.leerDatoEntero("\t" + "Digite la cantidad de piezas que tenga la pijama:  ");
        diseño = vista.leerDatoTexto("\t" + "Digite tipo de diseño que desea para la pijama: ");

       
        PijamaFactory fabrica=new PijamaCreador();
        
        Pijama pijama = fabrica.crearPijama(tela,cantidadPiezas,diseño);
        
        vista.mostrarInformacion("LA TELA DE LA PIJAMA ES....." + pijama.describir() );
        
    }
    
}
