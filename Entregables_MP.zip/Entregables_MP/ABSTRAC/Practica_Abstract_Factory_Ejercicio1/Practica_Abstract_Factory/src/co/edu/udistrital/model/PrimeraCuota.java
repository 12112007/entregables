package co.edu.udistrital.model;

import co.edu.udistrital.model.fabricaAbstracta.ServicioPrestamo;

public class PrimeraCuota implements ServicioPrestamo{
    
    @Override
    public String validarNombreCliente(){
		return "El nombre del cliente para el pago de la primera cuota es valido";
    }
    @Override
    public String validarID(){
		return "El ID del cliente para el pago de la primera cuota es valido";
    }
    
    @Override
    public String validarDireccion(){
		return "La direccion del cliente para el pago de la primera cuota es valida";
    }
    
}
