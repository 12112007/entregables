package co.edu.udistrital.model;

import co.edu.udistrital.model.fabricaAbstracta.ServicioPrestamo;

public class SegundaCuota implements ServicioPrestamo {

	@Override
	public String validarNombreCliente() {
		return "El nombre del cliente para el pago de la segunda cuota es valido";
	}

	@Override
	public String validarID() {
		return "El ID del cliente para el pago de la segunda cuota es valido";
	}

	@Override
	public String validarDireccion() {
		return "La direccion del cliente para el pago de la segunda cuota es valida";
	}
}
