package co.edu.udistrital.model.fabricaAbstracta;

public interface ServicioPrestamo {
	
	String validarNombreCliente();
	String validarID();
	String validarDireccion();
	
}
