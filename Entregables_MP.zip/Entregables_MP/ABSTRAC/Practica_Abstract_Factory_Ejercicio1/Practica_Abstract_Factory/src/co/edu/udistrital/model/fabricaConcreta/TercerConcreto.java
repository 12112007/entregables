package co.edu.udistrital.model.fabricaConcreta;

import co.edu.udistrital.model.TerceraCuota;
import co.edu.udistrital.model.fabricaAbstracta.ServicioFactory;
import co.edu.udistrital.model.fabricaAbstracta.ServicioPrestamo;

public class TercerConcreto implements ServicioFactory{
    
    @Override
    public ServicioPrestamo crearPrestamo(){
      return new  TerceraCuota();
      
    }
    
}
