package co.edu.udistrital.model.fabricaConcreta;

import co.edu.udistrital.model.LibrosDeCienciaFiccion;
import co.edu.udistrital.model.fabricaAbstracta.ServicioFactory;
import co.edu.udistrital.model.fabricaAbstracta.ServicioLibros;

public class ConcretoCienciaFiccion implements ServicioFactory {

	@Override
	public ServicioLibros crearLibro() {
		return new LibrosDeCienciaFiccion();
	}
	
}
