package co.edu.udistrital.model;

import co.edu.udistrital.model.fabricaAbstracta.ServicioLibros;

public class LibrosDeDrama implements ServicioLibros {

	@Override
    public String validarGeneroLiterario(){
       return "El genero del libro es Drama";
    }
    
    @Override
    public String validarCodigo(){
    	return "El codigo del libro es DR123";
    }
    
    @Override
    public String validarDisponibilidadEjemplares(){
    	return "Existen tres ejemplares disponibles";
    }
}
