package co.edu.udistrital.model;

import co.edu.udistrital.model.fabricaAbstracta.ServicioLibros;

public class LibrosDeHistoria implements ServicioLibros {

	@Override
    public String validarGeneroLiterario(){
       return "El genero del libro es Historia";
    }
    
    @Override
    public String validarCodigo(){
    	return "El codigo del libro es HI123";
    }
    
    @Override
    public String validarDisponibilidadEjemplares(){
    	return "Existen cinco ejemplares disponibles";
    }
}
