package co.edu.udistrital.controller;

import co.edu.udistrital.model.fabricaAbstracta.*;
import co.edu.udistrital.model.fabricaConcreta.ConcretoCienciaFiccion;
import co.edu.udistrital.model.fabricaConcreta.ConcretoDrama;
import co.edu.udistrital.model.fabricaConcreta.ConcretoHistoria;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

	private VistaConsola vista;
	
    public Controller() {
    	vista = new VistaConsola();
	}
    
    public void run() {
    	int op = 0;
        do{
            op=menu();
            switch(op){
                case 1:
                	genero(new ConcretoCienciaFiccion());
                    break;
                case 2:
                	genero(new ConcretoDrama());
                    break;
                case 3:
                	genero(new ConcretoHistoria());
                    break;
                case 4:
                	vista.mostrarInformacion("Cerrando Programa");
                    System.exit(0);
                 default :
                	 vista.mostrarInformacion(".....Opcion invalida....");
            }
            vista.mostrarInformacion("");
        }while(op!=4);
    }
    
    public void genero(ServicioFactory Libros){
        ServicioLibros servicio = Libros.crearLibro();
        vista.mostrarInformacion(servicio.validarGeneroLiterario());  
        vista.mostrarInformacion(servicio.validarCodigo());
        vista.mostrarInformacion(servicio.validarDisponibilidadEjemplares());
        
    }
    
    public int  menu(){
        String menu2 = 
                "MENU DE OPCIONES\n"
                + "1.   Solicitar Libro De Ciencia Ficcion. \n"
                + "2.   Solicitar Libro De Drama. \n"
                + "3.   Solicitar Libro De Historia. \n"
                + "4.   Cerrar programa. \n\n"
                + "Seleccion opcion...";
        return vista.leerDatoEntero(menu2);
    }
    
}
