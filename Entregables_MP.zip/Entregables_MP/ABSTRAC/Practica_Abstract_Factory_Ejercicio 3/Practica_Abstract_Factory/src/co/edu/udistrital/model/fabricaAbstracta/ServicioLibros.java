package co.edu.udistrital.model.fabricaAbstracta;

public interface ServicioLibros {
	
	String validarGeneroLiterario();
	String validarCodigo();
	String validarDisponibilidadEjemplares();
	
	
}
