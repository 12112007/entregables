package co.edu.udistrital.model.fabricaAbstracta;

public interface ServicioFactory {
	
	ServicioLibros crearLibro();
	
}
