package co.edu.udistrital.model.fabricaConcreta;

import co.edu.udistrital.model.LibrosDeDrama;
import co.edu.udistrital.model.fabricaAbstracta.ServicioFactory;
import co.edu.udistrital.model.fabricaAbstracta.ServicioLibros;


public class ConcretoDrama implements ServicioFactory {

	@Override
	public ServicioLibros crearLibro() {
		return new LibrosDeDrama();
	}
	
}
