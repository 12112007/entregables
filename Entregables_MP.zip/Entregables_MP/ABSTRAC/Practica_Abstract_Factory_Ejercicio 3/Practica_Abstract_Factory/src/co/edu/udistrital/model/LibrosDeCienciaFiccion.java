package co.edu.udistrital.model;

import co.edu.udistrital.model.fabricaAbstracta.ServicioLibros;

public class LibrosDeCienciaFiccion implements ServicioLibros{
    
    @Override
    public String validarGeneroLiterario(){
       return "El genero del libro es Ciencia Ficcion";
    }
    
    @Override
    public String validarCodigo(){
    	return "El codigo del libro es CF123";
    }
    
    @Override
    public String validarDisponibilidadEjemplares(){
    	return "No disponible";
    }
    
}
