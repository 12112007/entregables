package co.edu.udistrital.model.fabricaConcreta;

import co.edu.udistrital.model.Buseta;
import co.edu.udistrital.model.fabricaAbstracta.VehiculoDeTransporteFactory;
import co.edu.udistrital.model.fabricaAbstracta.InterfazServicioVehiculo;


public class BusetasConcreto implements VehiculoDeTransporteFactory {

	@Override
	 public InterfazServicioVehiculo crearVehiculo() {
	  Buseta miBuseta=new Buseta();
	  miBuseta.setCodigo(miBuseta.generarCodigo());
	  System.out.println("Se ha creado un nuevo Objeto Buseta");
	  return miBuseta;
	 }
	
	
	
}
