package co.edu.udistrital.model;

import co.edu.udistrital.model.fabricaAbstracta.InterfazServicioVehiculo;

public class Buseta implements InterfazServicioVehiculo {

	private int codigo;
	
	public int generarCodigo(){
	  int codigoBuseta=(int) (Math.random()*9999);
	  return codigoBuseta;
	 }
	
	 public int getCodigo() {
	  return codigo;
	 }
	 
	 public void setCodigo(int codigo) {
	  this.codigo = codigo;
	 }
	 
	 @Override
	 public void codigoDeVehiculo() {
		 System.out.println("El Codigo de la Buseta es:"+getCodigo());
	
	 }
	
}
