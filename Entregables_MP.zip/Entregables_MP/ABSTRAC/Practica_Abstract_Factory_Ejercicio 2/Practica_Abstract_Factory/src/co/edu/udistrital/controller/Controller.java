package co.edu.udistrital.controller;

import co.edu.udistrital.model.fabricaAbstracta.*;
import co.edu.udistrital.model.fabricaConcreta.BusesConcreto;
import co.edu.udistrital.model.fabricaConcreta.BusetasConcreto;
import co.edu.udistrital.model.fabricaConcreta.TaxiConcreto;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

	private VistaConsola vista;
	
    public Controller() {
    	vista = new VistaConsola();
	}
    
    public void run() {
    	int op = 0;
        do{
            op=menu();
            switch(op){
                case 1:
                	opcion(new TaxiConcreto());
                    break;
                case 2:
                	opcion(new BusesConcreto());
                    break;
                case 3:
                	opcion(new BusetasConcreto());
                    break;
                case 4:
                	vista.mostrarInformacion("Cerrando Programa");
                    System.exit(0);
                 default :
                	 vista.mostrarInformacion(".....Opcion invalida....");
            }
            vista.mostrarInformacion("");
        }while(op!=4);
    }
    
    public void opcion(VehiculoDeTransporteFactory Vehiculo){
        InterfazServicioVehiculo servicio = Vehiculo.crearVehiculo();
        vista.mostrarCodigo(servicio.generarCodigo()); 
    }
    
    public int  menu(){
        String menu2 = 
                "Ingrese la opción correspondiente para obtener el codigo del servicio\n"
                + "1. Codigo servicio de Taxis\n"
                + "2. Codigo servicio de Buses\n"
                + "3. Codigo servicio de Busetas\n"
                + "4. Cerrar programa. \n"
                + "Seleccion opcion...";
        return vista.leerDatoEntero(menu2);
    }
    
}
