package co.edu.udistrital.model;
import co.edu.udistrital.model.fabricaAbstracta.InterfazServicioVehiculo;

public class Bus implements InterfazServicioVehiculo{
    
	private int codigo;
	 
	public int generarCodigo(){
	  int codigoBus=(int) (Math.random()*9999);
	  return codigoBus;
	 }
	
	 public int getCodigo() {
	  return codigo;
	 }
	 
	 public void setCodigo(int codigo) {
	  this.codigo = codigo;
	 }
	 
	 @Override
	 public void codigoDeVehiculo() {
		 System.out.println("El Codigo del Bus es : "+getCodigo());
	 }
	 
    
}
