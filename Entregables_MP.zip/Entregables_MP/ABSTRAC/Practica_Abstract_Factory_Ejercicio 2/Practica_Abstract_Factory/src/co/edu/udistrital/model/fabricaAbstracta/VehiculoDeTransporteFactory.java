package co.edu.udistrital.model.fabricaAbstracta;

public interface VehiculoDeTransporteFactory {
	
	InterfazServicioVehiculo crearVehiculo();


	
}
