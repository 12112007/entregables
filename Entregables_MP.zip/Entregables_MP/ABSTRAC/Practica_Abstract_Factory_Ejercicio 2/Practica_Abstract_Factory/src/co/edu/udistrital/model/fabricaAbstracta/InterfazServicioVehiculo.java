package co.edu.udistrital.model.fabricaAbstracta;

public interface InterfazServicioVehiculo {
	
	void codigoDeVehiculo();
	int generarCodigo();
	
	
}
