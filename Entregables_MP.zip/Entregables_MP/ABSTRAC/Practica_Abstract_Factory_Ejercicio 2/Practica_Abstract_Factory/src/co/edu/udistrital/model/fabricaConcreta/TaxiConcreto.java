package co.edu.udistrital.model.fabricaConcreta;

import co.edu.udistrital.model.Taxi;
import co.edu.udistrital.model.fabricaAbstracta.VehiculoDeTransporteFactory;
import co.edu.udistrital.model.fabricaAbstracta.InterfazServicioVehiculo;

public class TaxiConcreto implements VehiculoDeTransporteFactory{
    
	@Override
	 public InterfazServicioVehiculo crearVehiculo() {
	  Taxi miTaxi=new Taxi();
	  miTaxi.setCodigo(miTaxi.generarCodigo());
	  System.out.println( "Se ha creado un nuevo Objeto Taxi");
	  return miTaxi;
	 }
    
}
