package co.edu.udistrital.model.fabricaConcreta;
import co.edu.udistrital.model.fabricaAbstracta.InterfazServicioVehiculo;
import co.edu.udistrital.model.fabricaAbstracta.VehiculoDeTransporteFactory;

public class FabricaDeVehiculos {

	public static void crearFabricaDeVehiculo(VehiculoDeTransporteFactory factory){
		  /**Aplicamos Polimorfismo*/
		InterfazServicioVehiculo objetoVehiculo= factory.crearVehiculo();
		  objetoVehiculo.codigoDeVehiculo();
		 }
}
