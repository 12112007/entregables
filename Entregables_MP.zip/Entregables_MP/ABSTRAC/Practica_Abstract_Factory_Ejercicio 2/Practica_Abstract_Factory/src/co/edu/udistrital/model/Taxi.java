package co.edu.udistrital.model;

import co.edu.udistrital.model.fabricaAbstracta.InterfazServicioVehiculo;

public class Taxi implements InterfazServicioVehiculo {

	private int codigo;
	 
	public int generarCodigo(){
	  int codigoTaxi=(int) (Math.random()*9999);
	  return codigoTaxi;
	 }
	
	 public int getCodigo() {
	  return codigo;
	 }
	 
	 public void setCodigo(int codigo) {
	  this.codigo = codigo;
	 }
	 
	 @Override
	 public void codigoDeVehiculo() {
		 System.out.println("El Codigo del Taxi es : "+getCodigo());
	 }

}
