package co.edu.udistrital.model.fabricaConcreta;

import co.edu.udistrital.model.Bus;
import co.edu.udistrital.model.fabricaAbstracta.InterfazServicioVehiculo;
import co.edu.udistrital.model.fabricaAbstracta.VehiculoDeTransporteFactory;

public class BusesConcreto implements VehiculoDeTransporteFactory {
	
	@Override
	public InterfazServicioVehiculo crearVehiculo() {
		  Bus miBus=new Bus();
		  miBus.setCodigo(miBus.generarCodigo());
		  System.out.println("Se ha creado un nuevo Objeto Bus ");
		  return miBus;
		 }

	//NI ENTIENDOO POR QUE SALE EL ERROR 
	
}
