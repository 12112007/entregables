package cliente;

public class Cliente {

    private String nombre;
    private boolean tieneDeudas;

    public Cliente(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public boolean isTieneDeudas() {
        return tieneDeudas;
    }

    public void setTieneDeudas(boolean tieneDeudas) {
        this.tieneDeudas = tieneDeudas;
    }

    public void mostrar() {
        System.out.println("Estudiante: " + nombre + "\n");
    }
}

