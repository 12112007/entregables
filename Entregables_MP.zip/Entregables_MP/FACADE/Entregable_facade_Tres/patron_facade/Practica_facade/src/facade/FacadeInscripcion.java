package facade;

import cliente.Cliente;
import modulos.VerificadorRequisitos;
import modulos.ControlFinanciero;
import modulos.RegistroCurso;

public class FacadeInscripcion {

    public boolean inscribirCurso(Cliente estudiante) {
        VerificadorRequisitos requisitos = new VerificadorRequisitos();
        ControlFinanciero finanzas = new ControlFinanciero();
        RegistroCurso registro = new RegistroCurso();

        if (requisitos.cumpleRequisitos(estudiante) && finanzas.estaAlDia(estudiante)) {
            registro.registrar(estudiante);
            System.out.println("Inscripción completada exitosamente.");
            return true;
        } else {
            System.out.println("Inscripción fallida. Verifique requisitos o pagos.");
            return false;
        }
    }
}
