package practica_facade;

import cliente.Cliente;
import facade.FacadeInscripcion;
import java.util.Scanner;

public class Practica_facade {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Nombre del estudiante: ");
        String nombre = sc.nextLine();

        Cliente estudiante = new Cliente(nombre);

        System.out.print("¿Tiene deudas pendientes? (si/no): ");
        String respuesta = sc.nextLine().toLowerCase();
        estudiante.setTieneDeudas(respuesta.equals("si"));

        estudiante.mostrar();
        boolean resultado = new FacadeInscripcion().inscribirCurso(estudiante);

        System.out.println("Resultado final: " + resultado);
    }
}

