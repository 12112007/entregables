package modulos;

import cliente.Cliente;

public class VerificadorRequisitos {

    public boolean cumpleRequisitos(Cliente c) {
        System.out.println("Revisión de requisitos académicos: Aprobado");
        return true;
    }
}

