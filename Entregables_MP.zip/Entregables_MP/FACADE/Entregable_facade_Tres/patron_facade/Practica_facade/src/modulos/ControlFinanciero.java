package modulos;

import cliente.Cliente;

public class ControlFinanciero {

    public boolean estaAlDia(Cliente c) {
        if (c.isTieneDeudas()) {
            System.out.println("El estudiante tiene deudas pendientes.");
            return false;
        }
        System.out.println("El estudiante no tiene deudas.");
        return true;
    }
}
