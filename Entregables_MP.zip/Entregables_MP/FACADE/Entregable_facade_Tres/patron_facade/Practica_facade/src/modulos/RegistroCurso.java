package modulos;

import cliente.Cliente;

public class RegistroCurso {

    public void registrar(Cliente c) {
        System.out.println("Inscripción realizada en el sistema académico.");
    }
}
