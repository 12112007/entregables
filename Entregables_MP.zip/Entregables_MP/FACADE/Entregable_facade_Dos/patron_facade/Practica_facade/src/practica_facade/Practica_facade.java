package practica_facade;

import cliente.Cliente;
import facade.FacadeReservaVuelo;
import java.util.Scanner;

public class Practica_facade {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Ingrese nombre del cliente: ");
        String nombre = sc.nextLine();
        Cliente cliente = new Cliente(nombre);

        System.out.print("¿El cliente tiene pasaporte? (si/no): ");
        String tienePasaporte = sc.nextLine().trim().toLowerCase();
        cliente.setPasaporte(tienePasaporte.equals("si"));

        cliente.mostrarInfo();
        boolean exito = new FacadeReservaVuelo().reservarVuelo(cliente);

        System.out.println("Resultado de la operación: " + exito);
    }
}

