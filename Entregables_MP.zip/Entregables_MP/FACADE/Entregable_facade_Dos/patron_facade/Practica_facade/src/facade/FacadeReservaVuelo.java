package facade;

import cliente.Cliente;
import modulos.VerificacionIdentidad;
import modulos.DisponibilidadVuelo;
import modulos.PagoVuelo;

public class FacadeReservaVuelo {

    public boolean reservarVuelo(Cliente cliente) {
        VerificacionIdentidad verificador = new VerificacionIdentidad();
        DisponibilidadVuelo disponibilidad = new DisponibilidadVuelo();
        PagoVuelo pago = new PagoVuelo();

        if (verificador.verificar(cliente) &&
            disponibilidad.hayDisponibilidad(cliente) &&
            pago.procesarPago(cliente)) {
            System.out.println("Reservación completada con éxito.");
            return true;
        } else {
            System.out.println("Reservación fallida.");
            return false;
        }
    }
}

