package modulos;

import cliente.Cliente;

public class VerificacionIdentidad {

    public boolean verificar(Cliente cliente) {
        if (cliente.tienePasaporte()) {
            System.out.println("Identidad verificada con pasaporte.");
            return true;
        } else {
            System.out.println("No tiene pasaporte válido.");
            return false;
        }
    }
}

