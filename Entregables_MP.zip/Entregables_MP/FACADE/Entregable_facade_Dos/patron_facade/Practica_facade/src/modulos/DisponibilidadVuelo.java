package modulos;

import cliente.Cliente;

public class DisponibilidadVuelo {

    public boolean hayDisponibilidad(Cliente cliente) {
        System.out.println("Hay vuelos disponibles para el cliente.");
        return true;
    }
}

