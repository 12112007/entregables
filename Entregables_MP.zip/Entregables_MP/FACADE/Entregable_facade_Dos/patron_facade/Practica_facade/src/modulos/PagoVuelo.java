package modulos;

import cliente.Cliente;

public class PagoVuelo {

    public boolean procesarPago(Cliente cliente) {
        System.out.println("Pago procesado correctamente.");
        return true;
    }
}
