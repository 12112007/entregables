package cliente;

public class Cliente {

    private String nombre;
    private boolean pasaporte;

    public Cliente(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public boolean tienePasaporte() {
        return pasaporte;
    }

    public void setPasaporte(boolean pasaporte) {
        this.pasaporte = pasaporte;
    }

    public void mostrarInfo() {
        System.out.println("Cliente: " + nombre + "\n");
    }
}

