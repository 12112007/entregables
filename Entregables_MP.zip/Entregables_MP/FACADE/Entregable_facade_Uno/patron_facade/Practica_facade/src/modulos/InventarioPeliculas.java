package modulos;

import cliente.Cliente;

public class InventarioPeliculas {

    public boolean verificarDisponibilidad(Cliente c) {
        System.out.println("La película está disponible.");
        return true;
    }
}

