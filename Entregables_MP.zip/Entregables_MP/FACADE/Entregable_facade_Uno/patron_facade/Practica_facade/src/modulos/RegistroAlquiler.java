package modulos;

import cliente.Cliente;

public class RegistroAlquiler {

    public void registrar(Cliente c) {
        System.out.println("El alquiler se ha registrado en el sistema.");
    }
}

