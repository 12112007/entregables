package modulos;

import cliente.Cliente;

public class ValidacionMembresia {

    public boolean validar(Cliente c) {
        if (c.tieneMembresia()) {
            System.out.println("El cliente tiene membresía activa.");
            return true;
        } else {
            System.out.println("El cliente NO tiene membresía activa.");
            return false;
        }
    }
}
