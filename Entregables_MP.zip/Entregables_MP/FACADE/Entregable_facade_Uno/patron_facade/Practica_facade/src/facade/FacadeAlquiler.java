package facade;

import cliente.Cliente;
import modulos.InventarioPeliculas;
import modulos.ValidacionMembresia;
import modulos.RegistroAlquiler;

public class FacadeAlquiler {

    public boolean alquilarPelicula(Cliente cliente) {
        ValidacionMembresia val = new ValidacionMembresia();
        InventarioPeliculas inv = new InventarioPeliculas();
        RegistroAlquiler reg = new RegistroAlquiler();

        if (val.validar(cliente) && inv.verificarDisponibilidad(cliente)) {
            reg.registrar(cliente);
            System.out.println("Película alquilada con éxito.");
            return true;
        } else {
            System.out.println("No se pudo realizar el alquiler.");
            return false;
        }
    }
}


