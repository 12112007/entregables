package practica_facade;

import cliente.Cliente;
import facade.FacadeAlquiler;
import java.util.Scanner;

public class Practica_facade {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Ingrese el nombre del cliente: ");
        String nombre = sc.nextLine();

        Cliente cliente = new Cliente(nombre);

        System.out.print("¿Tiene membresía activa? (si/no): ");
        String resp = sc.nextLine().toLowerCase();
        cliente.setMembresia(resp.equals("si"));

        cliente.mostrar();
        boolean exito = new FacadeAlquiler().alquilarPelicula(cliente);

        System.out.println("Resultado final: " + exito);
    }
}


