package cliente;

public class Cliente {

    private String nombre;
    private boolean membresia;

    public Cliente(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public boolean tieneMembresia() {
        return membresia;
    }

    public void setMembresia(boolean membresia) {
        this.membresia = membresia;
    }

    public void mostrar() {
        System.out.println("Cliente: " + nombre + "\n");
    }
}


